import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, GripVertical } from 'lucide-react';
import { useCMS } from '../../../context/CMSContext';
import { STAGING_TAG_ID, isFootageInStaging } from '../../../services/seedData';
import { ComputedFootage } from '../../../types/footage.types';
import { CategoryTag, SystemSettings } from '../../../types/tag.types';
import { PaginationBar } from '../../ui/PaginationBar';
import { StatusBadge } from '../../ui/StatusBadge';
import { TagPill } from '../../ui/TagPill';
import { FootageCard } from '../FootageCard';
import { ActiveScopeDescription, VaultViewMode } from './vault.types';

export interface VaultFootageResultsSectionProps {
  resultsTransitionKey: string;
  activeScopeDescription: ActiveScopeDescription;
  viewMode: VaultViewMode;
  filteredCount: number;
  paginatedFootage: ComputedFootage[];
  tagMap: Record<string, CategoryTag>;
  settings: SystemSettings;
  currentPage: number;
  pageSize: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
  onSelectForTraceability: (id: string) => void;
  onQuickTagClick: (tagId: string) => void;
  onSelectWithRange: (footageId: string, shiftKey?: boolean) => void;
  onStartDragFootage: (footageId: string) => string[];
  onEndDragFootage: () => void;
  onResetFilters: () => void;
  onOpenDirectFootageModal: () => void;
}

export const VaultFootageResultsSection: React.FC<VaultFootageResultsSectionProps> = ({
  resultsTransitionKey,
  activeScopeDescription,
  viewMode,
  filteredCount,
  paginatedFootage,
  tagMap,
  settings,
  currentPage,
  pageSize,
  onPageChange,
  onPageSizeChange,
  onSelectForTraceability,
  onQuickTagClick,
  onSelectWithRange,
  onStartDragFootage,
  onEndDragFootage,
  onResetFilters,
  onOpenDirectFootageModal,
}) => {
  const {
    selectedFootageIdsForBatch,
    setSelectedFootageIdsForBatch,
    activeDragFootageIds,
  } = useCMS();

  const isAllPaginatedSelected =
    paginatedFootage.length > 0 &&
    paginatedFootage.every((ft) => selectedFootageIdsForBatch.includes(ft.id));

  const handleToggleSelectAllPaginated = () => {
    if (isAllPaginatedSelected) {
      const pageIdSet = new Set(paginatedFootage.map((f) => f.id));
      setSelectedFootageIdsForBatch((prev) => prev.filter((id) => !pageIdSet.has(id)));
    } else {
      const newSelected = Array.from(
        new Set([...selectedFootageIdsForBatch, ...paginatedFootage.map((f) => f.id)])
      );
      setSelectedFootageIdsForBatch(newSelected);
    }
  };

  const handleToggleSelectOne = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    onSelectWithRange(id, e?.shiftKey);
  };

  const handleRowDragStart = (e: React.DragEvent<HTMLTableRowElement>, footageId: string) => {
    const batchIds = onStartDragFootage(footageId);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('application/x-footage-ids', JSON.stringify(batchIds));
    e.dataTransfer.setData('text/plain', batchIds.join(','));
  };

  return (
    <AnimatePresence mode="wait" initial={false}>
      {filteredCount === 0 ? (
        <motion.div
          key={`empty-${resultsTransitionKey}`}
          initial={{ opacity: 0, y: 12, scale: 0.98, filter: 'blur(4px)' }}
          animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
          exit={{ opacity: 0, y: -8, scale: 0.98, filter: 'blur(3px)' }}
          transition={{ type: 'spring', stiffness: 380, damping: 30 }}
          className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-2.5"
        >
          <p className="text-sm sm:text-base font-bold text-slate-900">
            ไม่พบคลิปที่ตรงกับตัวกรอง
          </p>
          <div className="pt-1 flex items-center justify-center gap-2.5">
            <button
              type="button"
              onClick={onResetFilters}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 cursor-pointer"
            >
              ล้างตัวกรอง
            </button>
          </div>
        </motion.div>
      ) : viewMode === 'GRID' ? (
        <motion.div
          key={`grid-${resultsTransitionKey}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.12 } }}
          className="space-y-4"
        >
          <motion.div
            layout
            className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5"
          >
            {paginatedFootage.map((ft, index) => (
              <motion.div
                key={ft.id}
                layout="position"
                initial={{
                  opacity: 0,
                  y: 22,
                  scale: 0.95,
                  filter: 'blur(4px)',
                }}
                animate={{
                  opacity: 1,
                  y: 0,
                  scale: 1,
                  filter: 'blur(0px)',
                }}
                exit={{
                  opacity: 0,
                  y: -12,
                  scale: 0.95,
                  filter: 'blur(3px)',
                }}
                transition={{
                  type: 'spring',
                  stiffness: 380,
                  damping: 26,
                  mass: 0.78,
                  delay: Math.min(index * 0.045, 0.32),
                }}
              >
                <FootageCard
                  footage={ft}
                  onSelectForTraceability={onSelectForTraceability}
                  onQuickTagClick={onQuickTagClick}
                  onSelectWithRange={onSelectWithRange}
                  onStartDragFootage={onStartDragFootage}
                  onEndDragFootage={onEndDragFootage}
                />
              </motion.div>
            ))}
          </motion.div>

          <PaginationBar
            currentPage={currentPage}
            totalItems={filteredCount}
            pageSize={pageSize}
            onPageChange={onPageChange}
            onPageSizeChange={onPageSizeChange}
            pageSizeOptions={[9, 18, 27, 45]}
            itemLabel="คลิป"
          />
        </motion.div>
      ) : (
        <motion.div
          key={`table-${resultsTransitionKey}`}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8, transition: { duration: 0.12 } }}
          transition={{ type: 'spring', stiffness: 400, damping: 30 }}
          className="space-y-4"
        >
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-2.5 px-3 w-14 text-center">
                      <input
                        type="checkbox"
                        checked={isAllPaginatedSelected}
                        onChange={handleToggleSelectAllPaginated}
                        className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer accent-indigo-600"
                        title="เลือกหน้านี้"
                      />
                    </th>
                    <th className="py-2.5 px-4 w-24">รหัส</th>
                    <th className="py-2.5 px-4">ชื่อคลิป</th>
                    <th className="py-2.5 px-4">หมวดหมู่</th>
                    <th className="py-2.5 px-4 w-36">สถานะ</th>
                    <th className="py-2.5 px-3 w-12 text-right"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {paginatedFootage.map((ft, index) => {
                    const isSelected = selectedFootageIdsForBatch.includes(ft.id);
                    const isBeingDragged = activeDragFootageIds.includes(ft.id);
                    return (
                      <motion.tr
                        key={ft.id}
                        draggable
                        onDragStartCapture={(e) => handleRowDragStart(e, ft.id)}
                        onDragEndCapture={onEndDragFootage}
                        initial={{
                          opacity: 0,
                          y: 14,
                          filter: 'blur(3px)',
                        }}
                        animate={{
                          opacity: 1,
                          y: 0,
                          filter: 'blur(0px)',
                        }}
                        transition={{
                          type: 'spring',
                          stiffness: 400,
                          damping: 28,
                          delay: Math.min(index * 0.035, 0.28),
                        }}
                        onClick={(e) => {
                          if (e.shiftKey) {
                            handleToggleSelectOne(ft.id, e);
                            return;
                          }
                          onSelectForTraceability(ft.id);
                        }}
                        className={`cursor-pointer transition-colors group ${
                          isBeingDragged
                            ? 'bg-indigo-100/80 opacity-65'
                            : isSelected
                            ? 'bg-indigo-50/70 hover:bg-indigo-100/60'
                            : 'hover:bg-slate-50'
                        }`}
                      >
                        <td
                          className="py-2.5 px-3 w-14 text-center"
                          onClick={(e) => handleToggleSelectOne(ft.id, e)}
                        >
                          <div className="inline-flex items-center gap-1">
                            <GripVertical className="w-3.5 h-3.5 text-slate-300 group-hover:text-slate-500 cursor-grab shrink-0" />
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {}}
                              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer accent-indigo-600"
                            />
                          </div>
                        </td>
                        <td className="py-2.5 px-4 font-mono font-bold text-slate-600 whitespace-nowrap tabular-nums">
                          {ft.id}
                        </td>
                        <td className="py-2.5 px-4">
                          <div className="font-bold text-slate-900 text-sm line-clamp-1">
                            {ft.title}
                          </div>
                        </td>
                        <td className="py-2.5 px-4">
                          {isFootageInStaging(ft.tags) ? (
                            <TagPill tag={tagMap[STAGING_TAG_ID]} />
                          ) : (
                            <div className="flex flex-wrap gap-1.5">
                              {ft.tags.map((tid) => (
                                <TagPill key={tid} tag={tagMap[tid]} />
                              ))}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-4 whitespace-nowrap">
                          <StatusBadge
                            status={ft.cooldownStatus}
                            daysSinceLastUse={ft.daysSinceLastUsed}
                            cooldownDays={settings.cooldownDays}
                            greenReadyDays={settings.greenReadyDays}
                            usageLast90Days={ft.usageLast90Days}
                            totalUsageCount={ft.totalUsageCount}
                            maxTotalUsageCount={settings.maxTotalUsageCount}
                            compact
                          />
                        </td>
                        <td className="py-2.5 px-3 text-right whitespace-nowrap">
                          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 inline-block" />
                        </td>
                      </motion.tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <PaginationBar
            currentPage={currentPage}
            totalItems={filteredCount}
            pageSize={pageSize}
            onPageChange={onPageChange}
            onPageSizeChange={onPageSizeChange}
            pageSizeOptions={[10, 20, 30, 50]}
            itemLabel="ฟุตเทจ"
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
};
