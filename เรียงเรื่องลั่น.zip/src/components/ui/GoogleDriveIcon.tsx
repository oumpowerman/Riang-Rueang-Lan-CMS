import React from 'react';

interface GoogleDriveIconProps {
  className?: string;
}

export const GoogleDriveIcon: React.FC<GoogleDriveIconProps> = ({
  className = 'w-4 h-4',
}) => (
  <svg
    viewBox="0 0 87.3 78"
    className={className}
    aria-hidden="true"
    focusable="false"
  >
    <path
      d="M6.6 66.85l3.85 6.65c.8 1.4 1.95 2.5 3.3 3.3l13.75-23.8H0c0 1.55.4 3.1 1.2 4.5l5.4 9.35z"
      fill="#0066da"
    />
    <path
      d="M43.65 25L29.9 1.2c-1.35.8-2.5 1.9-3.3 3.3L1.2 48.5c-.8 1.4-1.2 2.95-1.2 4.5h27.5L43.65 25z"
      fill="#00ac47"
    />
    <path
      d="M73.55 76.8c1.35-.8 2.5-1.9 3.3-3.3l1.6-2.75 7.65-13.25c.8-1.4 1.2-2.95 1.2-4.5H59.8l5.85 11.5 7.9 12.3z"
      fill="#ea4335"
    />
    <path
      d="M43.65 25L57.4 1.2C56.05.4 54.5 0 52.9 0H34.4c-1.6 0-3.15.45-4.5 1.2L43.65 25z"
      fill="#00832d"
    />
    <path
      d="M59.8 53H27.5L13.75 76.8c1.35.8 2.9 1.2 4.5 1.2h50.8c1.6 0 3.15-.45 4.5-1.2L59.8 53z"
      fill="#2684fc"
    />
    <path
      d="M73.4 26.5L60.7 4.5c-.8-1.4-1.95-2.5-3.3-3.3L43.65 25 59.8 53h27.45c0-1.55-.4-3.1-1.2-4.5L73.4 26.5z"
      fill="#ffba00"
    />
  </svg>
);
